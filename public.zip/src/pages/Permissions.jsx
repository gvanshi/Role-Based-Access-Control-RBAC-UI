import React, { useState, useEffect } from 'react';
import { getPermissions, createPermission, deletePermission } from '../services/api'; // Update with your actual API functions
import './Permissions.css';

const Permissions = () => {
  const [permissions, setPermissions] = useState([]); // State for permissions
  const [newPermission, setNewPermission] = useState(''); // State for adding a new permission
  const [loading, setLoading] = useState(true); // State for loading indicator

  useEffect(() => {
    fetchPermissions(); // Fetch permissions on component mount
  }, []);

  // Fetch permissions from the API
  const fetchPermissions = async () => {
    try {
      const response = await getPermissions();
      setPermissions(response?.data || []); // Ensure permissions is an array
    } catch (error) {
      console.error('Error fetching permissions:', error);
      setPermissions([]); // Fallback to an empty array
    } finally {
      setLoading(false); // End loading state
    }
  };

  // Add a new permission
  const handleAddPermission = async (e) => {
    e.preventDefault();
    if (newPermission.trim() === '') {
      alert('Permission name cannot be empty!');
      return;
    }

    try {
      await createPermission({ name: newPermission }); // API call to add permission
      setNewPermission(''); // Clear the input field
      fetchPermissions(); // Refresh the list
    } catch (error) {
      console.error('Error adding permission:', error);
    }
  };

  // Delete a permission
  const handleDeletePermission = async (id) => {
    if (window.confirm('Are you sure you want to delete this permission?')) {
      try {
        await deletePermission(id); // API call to delete permission
        fetchPermissions(); // Refresh the list
      } catch (error) {
        console.error('Error deleting permission:', error);
      }
    }
  };

  if (loading) {
    return <p>Loading permissions...</p>; // Show loading indicator
  }

  return (
    <div className="permissions-container">
      <h1>Permissions Management</h1>

      {/* Form to Add New Permission */}
      <form className="permissions-form" onSubmit={handleAddPermission}>
        <input
          type="text"
          placeholder="Enter new permission"
          value={newPermission}
          onChange={(e) => setNewPermission(e.target.value)}
        />
        <button type="submit" className="add-button">Add Permission</button>
      </form>

      {/* List of Permissions */}
      {permissions.length > 0 ? (
        <ul className="permissions-list">
          {permissions.map((permission) => (
            <li key={permission.id} className="permission-item">
              <span>{permission.name}</span>
              <button
                onClick={() => handleDeletePermission(permission.id)}
                className="delete-button"
              >
                Delete
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <p>No permissions available. Add a new permission to get started.</p>
      )}
    </div>
  );
};

export default Permissions;
