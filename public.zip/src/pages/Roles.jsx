import React, { useState, useEffect } from 'react';
import { getRoles, createRole, updateRole, deleteRole } from '../services/api';
import './Roles.css';

const Roles = () => {
  const [roles, setRoles] = useState([]); // Roles state
  const [form, setForm] = useState({ id: null, name: '', permissions: [] }); // Form state
  const [isEditing, setIsEditing] = useState(false); // Edit mode state
  const [loading, setLoading] = useState(true); // Loading state
  const availablePermissions = ['Read', 'Write', 'Delete', 'Manage Users', 'Approve Content']; // Permissions list

  useEffect(() => {
    // Fetch roles on component mount
    fetchRoles();
  }, []);

  // Fetch roles from API
  const fetchRoles = async () => {
    try {
      const response = await getRoles();
      setRoles(response?.data || []); // Ensure roles is an array
    } catch (error) {
      console.error('Error fetching roles:', error);
      setRoles([]); // Fallback to empty array
    } finally {
      setLoading(false); // Stop loading indicator
    }
  };

  // Form submission handler
  const handleFormSubmit = async (e) => {
    e.preventDefault();
    if (form.name.trim() === '') {
      alert('Role name cannot be empty!');
      return;
    }

    try {
      if (isEditing) {
        await updateRole(form.id, form); // Update existing role
      } else {
        await createRole(form); // Create a new role
      }

      setForm({ id: null, name: '', permissions: [] }); // Reset form
      setIsEditing(false); // Exit edit mode
      fetchRoles(); // Refresh roles
    } catch (error) {
      console.error('Error saving role:', error);
    }
  };

  // Delete role handler
  const handleDeleteRole = async (id) => {
    if (window.confirm('Are you sure you want to delete this role?')) {
      try {
        await deleteRole(id);
        fetchRoles(); // Refresh roles
      } catch (error) {
        console.error('Error deleting role:', error);
      }
    }
  };

  // Edit role handler
  const handleEditClick = (role) => {
    setForm(role);
    setIsEditing(true);
  };

  // Permission toggle handler
  const handlePermissionChange = (permission) => {
    setForm((prevForm) => ({
      ...prevForm,
      permissions: prevForm.permissions.includes(permission)
        ? prevForm.permissions.filter((perm) => perm !== permission)
        : [...prevForm.permissions, permission],
    }));
  };

  if (loading) {
    return <p>Loading roles...</p>;
  }

  return (
    <div className="roles-container">
      <h1>Roles Management</h1>

      {/* Role Form */}
      <form className="role-form" onSubmit={handleFormSubmit}>
        <input
          type="text"
          placeholder="Role Name"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          required
        />
        <div className="permissions-checkboxes">
          {availablePermissions.map((permission) => (
            <label key={permission}>
              <input
                type="checkbox"
                checked={form.permissions.includes(permission)}
                onChange={() => handlePermissionChange(permission)}
              />
              {permission}
            </label>
          ))}
        </div>
        <button type="submit" className="form-submit-button">
          {isEditing ? 'Update Role' : 'Add Role'}
        </button>
      </form>

      {/* Roles List */}
      {roles.length ? (
        <ul className="roles-list">
          {roles.map((role) => (
            <li key={role.id} className="roles-item">
              <div>
                <strong>{role.name}</strong>
                <p>Permissions: {role.permissions.join(', ') || 'None'}</p>
              </div>
              <div>
                <button onClick={() => handleEditClick(role)} className="edit-button">
                  Edit
                </button>
                <button onClick={() => handleDeleteRole(role.id)} className="delete-button">
                  Delete
                </button>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <p>No roles available. Please add a role.</p>
      )}
    </div>
  );
};

export default Roles;
