import React, { useState, useEffect } from 'react';
import { getUsers, deleteUser } from '../services/api';
import './Users.css';

const Users = () => {
  const [users, setUsers] = useState([]); // State to store users
  const [loading, setLoading] = useState(true); // State to manage loading

  // Fetch users when the component mounts
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const data = await getUsers(); // Fetch users from API
        setUsers(data); // Update state with fetched data
      } catch (error) {
        console.error('Error fetching users:', error);
      } finally {
        setLoading(false); // End loading state
      }
    };

    fetchUsers();
  }, []);

  // Handle delete user
  const handleDeleteUser = async (id) => {
    try {
      await deleteUser(id); // Call API to delete user
      setUsers(users.filter((user) => user.id !== id)); // Remove user from state
    } catch (error) {
      console.error('Error deleting user:', error);
    }
  };

  // Handle edit click (example stub)
  const handleEditClick = (user) => {
    alert(`Editing user: ${user.name}`);
  };

  // Show loading indicator if fetching data
  if (loading) {
    return <p>Loading users...</p>;
  }

  return (
    <div className="users-container">
      <h1>Users Management</h1>
      {users && users.length > 0 ? (
        <table className="users-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id}>
                <td>{user.name}</td>
                <td>{user.email}</td>
                <td>{user.role}</td>
                <td>{user.status}</td>
                <td>
                  <button onClick={() => handleEditClick(user)} className="edit-button">
                    Edit
                  </button>
                  <button onClick={() => handleDeleteUser(user.id)} className="delete-button">
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>No users found.</p>
      )}
    </div>
  );
};

export default Users;
